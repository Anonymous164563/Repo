package ATest;
 
import org.junit.*;
import static org.junit.Assert.*;
import java.lang.String;

	public class ATest {  
		
		
		static String StringTest = "StringTest";

		 public static void main(String[] args) { 
			 getLenght(); 
			 charAt();
			 subString(); 
			 indexOf();
		 }

		  @Test
		  public static void getLenght () {
		      System.out.println("The lenght of the StringTest is:");
			  int stringLenght = StringTest.length(); 
			  System.out.println(stringLenght);
		  }   
		  
		  @Test
		  public static void charAt() {
			  
			  System.out.println("The character at index 0 is:");
			  char result = StringTest.charAt(0); 
			  
	        System.out.println(result);
		  }
		  
		  @Test
		  public static void subString() { 
			  System.out.println("The substring at index 6:"); 
			  System.out.println(StringTest.substring(6));
		  }
          public static void indexOf() { 
        	  
        	  System.out.println("The index of StringTest is");
        	  String index = "StringTest";  
        	  System.out.println(index.indexOf("Test"));
        	  
          }
		  @Before
		  public void setUp() throws Exception {
		    // Common objects used by test methods may be set up here
		  }
		}





